package com.mizuho.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.mizuho.service.CostCalculation;

class EnergySupplierPalApplicationTests {
	
	@Test
	void validateInputWithValidInput()
	{
		List<Integer> mockinput = new ArrayList<>();
		mockinput.add(1000);
		mockinput.add(2000);
		
		List<Integer> inputConsumption  = CostCalculation.validateInput(new String[]{"C:\\Projects\\TestFolder\\plans.json","1000","2000"});
		assertEquals(mockinput, inputConsumption);
		assertEquals("C:\\Projects\\TestFolder\\plans.json",CostCalculation.filePath);
	}
	
	@Test
	void validateInputWithInvalidInput()
	{
		List<Integer> mockinput = new ArrayList<>();
		mockinput.add(1000);
		mockinput.add(2000);
		
		List<Integer> inputConsumption  = CostCalculation.validateInput(new String[]{"C:\\Projects\\TestFolder\\plans.json","gfgf","fgfg"});
		assertNotEquals(mockinput, inputConsumption);
	}
	
	@Test
	void validateInputWithoutInput()
	{
		List<Integer> mockinput = new ArrayList<>();
		mockinput.add(1000);
		mockinput.add(2000);
		
		List<Integer> inputConsumption  = CostCalculation.validateInput(new String[]{""});
		assertEquals(null, inputConsumption);
	}

	@Test
	void annualCostCalculationWithValidInput()
	{		
		CostCalculation.annualCostCalculation(1000);
		//Expected console output is below one
//		energyOne,planOne,108.68
//		energyThree,planThree,111.25
//		energyTwo,planTwo,120.23
//		energyFour,planFour,121.33
	}
	
	@Test
	void annualCostCalculationWithValidInput1()
	{		
		CostCalculation.annualCostCalculation(2000);
		//Expected console output is below one
//		energyThree,planThree,205.75
//		energyOne,planOne,213.68
//		energyFour,planFour,215.83
//		energyTwo,planTwo,235.73
	}
}
