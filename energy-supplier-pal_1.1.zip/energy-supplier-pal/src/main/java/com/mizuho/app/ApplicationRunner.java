package com.mizuho.app;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mizuho.model.Cost;
import com.mizuho.model.Plans;
import com.mizuho.model.Price;
import com.mizuho.service.CostCalculation;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

/**
 * 
 * This is command line runner class for running the command console
 * application.
 *
 */
@Component
public class ApplicationRunner implements CommandLineRunner {

	// Logger declaration
	private Logger logger = LoggerFactory.getLogger(ApplicationRunner.class);

	
	@Override
	public void run(String... args) throws Exception {

		// Validate the input parameters
		List<Integer> inputConsumption = CostCalculation.validateInput(args);

		if (inputConsumption != null) {
			// Call the annualCostCalculation for each input consumption
			for (Integer unitConsum : inputConsumption) {
				CostCalculation.annualCostCalculation(unitConsum);
			}
		}
	}
}