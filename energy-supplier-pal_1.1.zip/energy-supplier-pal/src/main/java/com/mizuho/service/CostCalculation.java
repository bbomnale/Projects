package com.mizuho.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mizuho.app.ApplicationRunner;
import com.mizuho.model.Cost;
import com.mizuho.model.Plans;
import com.mizuho.model.Price;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

public class CostCalculation {

	//Logger declaration
	private static Logger logger = LoggerFactory.getLogger(ApplicationRunner.class);

	// DEcalre the constant
	private static final int HUNDRED = 100;
	private static final int VAT = 5;
	private static final int DAYS = 365;
	private static final double HUNDRED_DECIMAL = 100.0;
	public static String filePath;

	
	/**
	 * @param args
	 * @return
	 * @throws NumberFormatException Validate the input parameters
	 */
	public static List<Integer> validateInput(String... args) throws NumberFormatException {
		List<Integer> inputConsumption = new ArrayList<>();

		try {
			// Validate the args input parameter.
			if (args.length > 1) {
				//System.out.println("The command line arguments are:");
				//logger.info("The command line arguments are: ");
				for (int i = 0; i < args.length; i++) {
					
					/*
					 * Validate the input JSON file with schema But could not validate as the schema
					 * file was created as per Mizuho specification standard
					 * "$schema":"http://json-schema.org/myenergypal/schema#"
					*/
					
					if(i==0){
						//getting error : Unknown MetaSchema: https://json-schema.org/myenergypal/schema
						//ValidateJson(args[i]); 
						filePath=args[i];
					}
					
					if (isNumeric(args[i])) {
						inputConsumption.add(Integer.parseInt(args[i]));
					}
				}

			} else {
				System.out.println("No command line " + "arguments found.");				
				return null;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return inputConsumption;
	}

	/**
	 * @param unitConsum : The input is annual kWh consumption. This function is to
	 *                   calculate the total cost for all the plans for each
	 *                   supplier
	 */
	public static void annualCostCalculation(Integer unitConsum) {

		TypeReference<List<Plans>> typeReference = new TypeReference<List<Plans>>() {
		};
		//InputStream inputStream = TypeReference.class.getResourceAsStream("C://Projects//TestFolder//plans.json"); filePath
		InputStream inputStream = TypeReference.class.getResourceAsStream("/data/plans.json");
		List<Plans> plans = null;
		try {
			plans = new ObjectMapper().readValue(inputStream, typeReference);
		} catch (IOException e) {
			logger.error("The JSON file loading is failed: " + e.getMessage());
			return;
		}

		int annualConsumption = unitConsum;
		List<Cost> tempAnnualcost = new ArrayList<>();

		try {
			if (plans != null && !plans.isEmpty()) {
				//Loop in all the plans for each supplier
				for (Plans plan : plans) {
					double totalAnnualCost = 0;
					int standaingCharges = 0;
					int tempAnnualConsumption = annualConsumption;
					double annualCost = 0;
					
					//Loop in all the rates with threshold to calculate the cost as per prices
					for (Price price : plan.getPrices()) {

						if (price.getThreshold() == 0) {
							annualCost = annualCost + (tempAnnualConsumption * price.getRate());
						} else {
							annualCost = annualCost + (price.getThreshold() * price.getRate());
							tempAnnualConsumption = tempAnnualConsumption - price.getThreshold();
						}
					}

					//Apply the standing  Charges if applicable as per yearly calculation
					if (!(plan.getStanding_charge() == 0)) {
						standaingCharges = plan.getStanding_charge() * DAYS;
					}

					//Apply the VAT
					totalAnnualCost = ((annualCost + standaingCharges)
							+ ((annualCost + standaingCharges) * VAT / HUNDRED)) / HUNDRED;
					
					//The annual cost is rounded to 2 decimal places 
					totalAnnualCost = Math.round(totalAnnualCost * HUNDRED_DECIMAL) / HUNDRED_DECIMAL;
					
					//Prepare the final list for print
					tempAnnualcost.add(new Cost(plan.getSupplier_name(), plan.getPlan_name(), totalAnnualCost));
				}

				// Display the annual cost in ascending	order and print
				Collections.sort(tempAnnualcost);
				for (Cost cost : tempAnnualcost) {
					System.out
							.println(cost.getSupplier_name() + "," + cost.getPlan_name() + "," + cost.getAnnualCost());
				}
			}
		} catch (Exception e) {
			logger.error("There is error in annula cost calculation: " + e.getMessage());
		}
	}

	/**
	 * 
	 * @param val Check if the input is numeric value or null
	 */
	private static boolean isNumeric(String val) {
		return val != null && val.matches("[0-9.]+");
	}
	
	/**
	 * Validate the input JSON file with schema
	 * But could not validate as the schema file was created as per Mizuho specification standard which is not accessible
	 * "$schema":"http://json-schema.org/myenergypal/schema#"
	 * getting error : Unknown MetaSchema: https://json-schema.org/myenergypal/schema
	 */
	private void ValidateJson() {
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			InputStream jsonStream = TypeReference.class.getResourceAsStream("/data/plans.json");
			InputStream schemaStream = TypeReference.class.getResourceAsStream("/data/schema.json");

			// create an instance of the JsonSchemaFactory using version flag
			JsonSchemaFactory schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V201909);

			// get schema from the schemaStream and store it into JsonSchema
			JsonSchema schema = schemaFactory.getSchema(schemaStream);

			JsonNode json = objectMapper.readTree(jsonStream);

			// create set of validation message and store result in it
			Set<ValidationMessage> validationResult = schema.validate(json);

			// show the validation errors
			if (validationResult.isEmpty()) {

				// show custom message if there is no validation error
				System.out.println("There are no validation errors");

			} else {

				// show all the validation error
				validationResult.forEach(vm -> System.out.println(vm.getMessage()));
			}
		} catch (Exception e) {			
			e.printStackTrace();
		}
	}	
}