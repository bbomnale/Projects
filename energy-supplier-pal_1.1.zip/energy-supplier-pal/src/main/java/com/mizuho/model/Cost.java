package com.mizuho.model;

public class Cost implements Comparable<Cost> {
	private String supplier_name;
	private String plan_name;
	private double annualCost;

	public Cost(String supplier_name, String plan_name, double annualCost) {
		this.supplier_name = supplier_name;
		this.plan_name = plan_name;
		this.annualCost = annualCost;
	}

	public String getSupplier_name() {
		return supplier_name;
	}

	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getPlan_name() {
		return plan_name;
	}

	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}

	public double getAnnualCost() {
		return annualCost;
	}

	public void setAnnualCost(double annualCost) {
		this.annualCost = annualCost;
	}

	Cost(double annualCost) {
		this.annualCost = annualCost;
	}

	@Override
	public int compareTo(Cost o) {
		return new Double(annualCost).compareTo(o.annualCost);
	}

	@Override
	public String toString() {
		return String.valueOf(annualCost);
	}
}