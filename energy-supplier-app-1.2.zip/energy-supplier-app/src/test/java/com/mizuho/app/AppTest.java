package com.mizuho.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.mizuho.service.CostCalculation;

/**
 * Unit test cases
 */
public class AppTest 
{
	
	@Test
    public void annualCostCalculationWithValidInput() {
    	CostCalculation.annualCostCalculation("C://Projects//TestFolder//plans.json","1000");       
    }
	
	@Test
    public void annualCostCalculationWithValidInput1() {
	   	CostCalculation.annualCostCalculation("C://Projects//TestFolder//plans.json","2000");  
    }
	
	@Test
    public void annualCostCalculationWithValidInput2() {
    	CostCalculation.annualCostCalculation("C://Projects//TestFolder//plans.json","0");       
    }	
	
//	@Test
//	public void annualCostCalculationWithInvalidFilePath() {
//	    Exception exception = assertThrows(RuntimeException.class, () -> {
//	    	CostCalculation.annualCostCalculation("temparWringfilepath","10000");  
//	    });
//
//	    String expectedMessage = "The json failed to convert into object No content to map due to end-of-input";
//	    String actualMessage = exception.getMessage();
//
//	    assertTrue(actualMessage.contains(expectedMessage));
//	}
//	
//	@Test
//	public void annualCostCalculationWithInvalidJSON() {
//	    Exception exception = assertThrows(RuntimeException.class, () -> {
//	    	CostCalculation.annualCostCalculation("C://Projects//TestFolder//plansIncorrect.json","10000");  
//	    });
//
//	    String expectedMessage = "The json failed to convert into object Unexpected character";
//	    String actualMessage = exception.getMessage();
//
//	    assertTrue(actualMessage.contains(expectedMessage));
//	}

//	@Test
//	public void annualCostCalculationWithInvalidAnnualConsumption() {
//	    Exception exception = assertThrows(RuntimeException.class, () -> {
//	    	CostCalculation.annualCostCalculation("C://Projects//TestFolder//plansIncorrect.json","dfdfdfdfd");  
//	    });
//
//	    String expectedMessage = "The entered annual consumption is not valid";
//	    String actualMessage = exception.getMessage();
//
//	    assertTrue(actualMessage.contains(expectedMessage));
//	}
	
	
//	@Test
//	public void annualCostCalculationWithInvalidJSON_WithWrongDataType() {
//	    Exception exception = assertThrows(RuntimeException.class, () -> {
//	    	CostCalculation.annualCostCalculation("C://Projects//TestFolder//plansWrongDataType.json","1000");  
//	    });
//
//	    String expectedMessage = "The json failed to convert into object Cannot deserialize value of type";
//	    String actualMessage = exception.getMessage();
//
//	    assertTrue(actualMessage.contains(expectedMessage));
//	}
	
	
    @Test
    public void isNumericWithValidInput() {
    	boolean result = CostCalculation.isNumeric("123");
        assertEquals(true, result);
    }
    
    @Test
    public void isNumericWithInvalidInput() {
    	boolean result = CostCalculation.isNumeric("1ererer23");
        assertNotEquals(true, result);
    }
    
    @Test
    public void isNumericWithInvalidInputSpeciChat() {
    	boolean result = CostCalculation.isNumeric("23232$#$#$#");
        assertNotEquals(true, result);
    }
    
    
    
}
