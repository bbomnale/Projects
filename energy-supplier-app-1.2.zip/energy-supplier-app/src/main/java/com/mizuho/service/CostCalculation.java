package com.mizuho.service;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mizuho.model.Cost;
import com.mizuho.model.Plans;
import com.mizuho.model.Price;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

public class CostCalculation {

	// Declare the constant
	private static final int HUNDRED = 100;
	private static final int VAT = 5;
	private static final int DAYS = 365;
	private static final double HUNDRED_DECIMAL = 100.0;
	public static String filePath;

	/**
	 * @param unitConsum : The input is annual kWh consumption. This function is to
	 *                   calculate the total cost for all the plans for each
	 *                   supplier
	 */
	public static void annualCostCalculation(String unitConsum, String filePath) {
		ValidateJson(filePath);
		String json = "";
		int annualConsumption=0;
		
		try {
			json = readFileAsString(filePath);
		} catch (Exception e1) {
			System.out.println(
					"There is issue for accessing the file, please check if the file path is correct or file is exist "+e1.getMessage());
		}

		System.out.println("");			
		if (CostCalculation.isNumeric(unitConsum)) {
			System.out.println("The annual total cost(GBP) for all plans for each supplier: ");
			annualConsumption = Integer.parseInt(unitConsum);
		}else{
			System.out.println("The entered annual consumtion is not valid : " + unitConsum);
			throw new NumberFormatException("The entered annual consumtion is not valid");  
		}
		
		List<Plans> plans = null;
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			plans = objectMapper.readValue(json, new TypeReference<List<Plans>>() {
			});			
		} catch (Exception e) {
			System.out.println("The json failed to convert into object " + e.getMessage());
		}
		
		List<Cost> tempAnnualcost = new ArrayList<>();

		try {
			if (plans != null && !plans.isEmpty()) {
				// Loop in all the plans for each supplier
				for (Plans plan : plans) {
					double totalAnnualCost = 0;
					int standaingCharges = 0;
					int tempAnnualConsumption = annualConsumption;
					double annualCost = 0;

					// Loop in all the rates with threshold to calculate the cost as per prices
					for (Price price : plan.getPrices()) {

						if (price.getThreshold() == 0) {
							annualCost = annualCost + (tempAnnualConsumption * price.getRate());
						} else {
							annualCost = annualCost + (price.getThreshold() * price.getRate());
							tempAnnualConsumption = tempAnnualConsumption - price.getThreshold();
						}
					}

					// Apply the standing Charges if applicable as per yearly calculation
					if (!(plan.getStanding_charge() == 0)) {
						standaingCharges = plan.getStanding_charge() * DAYS;
					}

					// Apply the VAT
					totalAnnualCost = ((annualCost + standaingCharges)
							+ ((annualCost + standaingCharges) * VAT / HUNDRED)) / HUNDRED;

					// The annual cost is rounded to 2 decimal places
					totalAnnualCost = Math.round(totalAnnualCost * HUNDRED_DECIMAL) / HUNDRED_DECIMAL;

					// Prepare the final list for print
					tempAnnualcost.add(new Cost(plan.getSupplier_name(), plan.getPlan_name(), totalAnnualCost));
				}

				// Display the annual cost in ascending order and print
				Collections.sort(tempAnnualcost);
				for (Cost cost : tempAnnualcost) {
					System.out
							.println(cost.getSupplier_name() + "," + cost.getPlan_name() + "," + cost.getAnnualCost());
				}
			}
		} catch (Exception e) {
			System.out.println("There is error in annula cost calculation:  " + e.getMessage());
		}
	}

	/**
	 * 
	 * @param val Check if the input is numeric value or null
	 */
	public static boolean isNumeric(String val) {
		return val != null && val.matches("[0-9.]+");
	}

	/**
	 * Validate the input JSON file with schema But could not validate as the schema
	 * file was created as per Mizuho specification standard which is not accessible
	 * outside "$schema":"http://json-schema.org/myenergypal/schema#" getting error
	 * : Unknown MetaSchema: https://json-schema.org/myenergypal/schema
	 * So I have created the new schema so I was able to validate it. 
	 */
	private static void ValidateJson(String filePath) {
		
		String schemaStr = "";
		
		try {
			schemaStr = readFileAsString(filePath);
		} catch (Exception e1) {
			System.out.println(
					"There is issue for accessing the file, please check if the file path is correct or file is exist "+e1.getMessage());
		}
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			//InputStream jsonStream = TypeReference.class.getResourceAsStream(filePath);
			//InputStream jsonStream = objectMapper.readValue(schemaStr, new TypeReference<InputStream>() {
			//});
			
			InputStream jsonStream = TypeReference.class.getResourceAsStream("/data/plansTemp.json");
			InputStream schemaStream = TypeReference.class.getResourceAsStream("/data/schemaTemp.json");
			
			
			// create an instance of the JsonSchemaFactory using version flag
			JsonSchemaFactory schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V201909);

			// get schema from the schemaStream and store it into JsonSchema
			JsonSchema schema = schemaFactory.getSchema(schemaStream);

			JsonNode json = objectMapper.readTree(jsonStream);

			// create set of validation message and store result in it
			Set<ValidationMessage> validationResult = schema.validate(json);

			// show the validation errors
			if (validationResult.isEmpty()) {
				// show custom message if there is no validation error
				System.out.println("There are no validation errors");

			} else {
				// show all the validation error
				validationResult.forEach(vm -> System.out.println(vm.getMessage()));				
			}			
		} catch (Exception e) {
			System.out.println("The JSON schema validation failed:  " + e.getMessage());
		}
	}

	/*
	 * Get the json file and convert it into string.
	 */
	public static String readFileAsString(String file) throws Exception {
		return new String(Files.readAllBytes(Paths.get(file)));
	}
}