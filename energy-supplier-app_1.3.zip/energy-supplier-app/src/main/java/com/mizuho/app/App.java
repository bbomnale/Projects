package com.mizuho.app;

import java.io.Console;
import com.mizuho.service.CostCalculation;

/**
 * * This is command line console application
 */
public class App {
	public static void main(String[] args) {
		
		while (true) {	
		
			System.out.println("My energy supplier pal application" + "\r\n");
			Console cnsl = System.console();

			String filePath = cnsl.readLine("Input <filename> : ");
			String annual_consumtion = cnsl.readLine("Enter Annual Consumtion : ");

			CostCalculation.annualCostCalculation(annual_consumtion, filePath);
			
			String exitStr = cnsl.readLine("Enter exit to terminate or ENTER to continue : ");
			if (exitStr.equalsIgnoreCase("exit")) {
				break;
			}
		}
	}    
}