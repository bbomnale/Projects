package com.mizuho.utils;

public final class Consts  {
	// Declare the constant
	public static final int HUNDRED = 100;
	public static final int VAT = 5;
	public static final int DAYS = 365;
	public static final double HUNDRED_DECIMAL = 100.0;
}
