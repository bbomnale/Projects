package com.mizuho.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;
import com.mizuho.service.CostCalculation;

/**
 * Unit test cases
 */
public class AppTest {

	@Test
	public void annualCostCalculationWithValidInput() {
		CostCalculation.annualCostCalculation("1000", "C://TestFolder//plans.json");
	}

	@Test
	public void annualCostCalculationWithValidInput1() {
		CostCalculation.annualCostCalculation("2000", "C://TestFolder//plans.json");
	}

	@Test
	public void annualCostCalculationWithValidInput2() {
		CostCalculation.annualCostCalculation("3500000", "C://TestFolder//plans.json");
	}

	@Test
	public void annualCostCalculationWithValidInput3() {
		CostCalculation.annualCostCalculation("0", "C://TestFolder//plans.json");
	}

	@Test(expected = NumberFormatException.class)
	public void testThrowsNumberFormatException() {
		CostCalculation.annualCostCalculation("-5", "C://TestFolder//plans.json");
	}

	@Test()
	public void annualCostCalculationWrongFileName() {
		CostCalculation.annualCostCalculation("0", "C://TestFolder//plansgggg.json");
	}

	@Test()
	public void annualCostCalculationWrongFilePath() {
		CostCalculation.annualCostCalculation("100", "C://TestFolder//Test//plans.json");
	}

	@Test()
	public void annualCostCalculationInvalidJsonFormat() {
		CostCalculation.annualCostCalculation("1000", "C://TestFolder//plansInvalidFormat.json");
	}

	@Test()
	public void annualCostCalculationplansWrongDataTypeInJSON() {
		CostCalculation.annualCostCalculation("1000", "C://TestFolder//plansWrongDataType.json");
	}

	@Test
	public void isNumericWithValidInput() {
		boolean result = CostCalculation.isNumeric("123");
		assertEquals(true, result);
	}

	@Test
	public void isNumericWithInvalidInput() {
		boolean result = CostCalculation.isNumeric("1ererer23");
		assertNotEquals(true, result);
	}

	@Test
	public void isNumericWithInvalidInputSpeciChat() {
		boolean result = CostCalculation.isNumeric("23232$#$#$#");
		assertNotEquals(true, result);
	}
}
