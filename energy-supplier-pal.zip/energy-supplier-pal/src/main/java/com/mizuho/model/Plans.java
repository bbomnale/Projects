package com.mizuho.model;

import java.util.ArrayList;

public class Plans {
	private String supplier_name;
	private String plan_name;
	private ArrayList<Price> prices;
	private int standing_charge;

	public String getSupplier_name() {
		return supplier_name;
	}

	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getPlan_name() {
		return plan_name;
	}

	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}

	public ArrayList<Price> getPrices() {
		return prices;
	}

	public void setPrices(ArrayList<Price> prices) {
		this.prices = prices;
	}

	public int getStanding_charge() {
		return standing_charge;
	}

	public void setStanding_charge(int standing_charge) {
		this.standing_charge = standing_charge;
	}
}