package com.mizuho.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergySupplierPalApplicationTests {

	@Test
	void contextLoads() {
	}

}
